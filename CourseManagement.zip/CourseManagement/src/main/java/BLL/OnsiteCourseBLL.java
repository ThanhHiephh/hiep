/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BLL;

import DAL.OnsiteCourseDAL;
import Model.OnlineCourse;
import Model.OnsiteCourse;
import java.util.ArrayList;

/**
 *
 * @author HP ADMIN
 */
public class OnsiteCourseBLL {
    private OnsiteCourseDAL ocDAL = new OnsiteCourseDAL();
    
    public ArrayList<OnsiteCourse> getAllOnsiteCourse(){
        return ocDAL.getAllOnsiteCourse();
    }
    
    public boolean checkOnsiteCourseID(int courseID){
        return ocDAL.checkOnsiteCourseID(courseID);
    }
    
    public ArrayList<Integer> getAllCourseID(){
        return ocDAL.getAllCourseID();
    }
    
    public boolean addOnsiteCourse(OnsiteCourse oc){
        return ocDAL.addOnsiteCourse(oc);
    }
    
    public boolean deleteOnsiteCourse(int courseID){
        return ocDAL.deleteOnsiteCourse(courseID);
    }
    
    public boolean updateOnsiteCourse(OnsiteCourse oc){
        return ocDAL.updateOnsiteCourse(oc);
    }
    
    public ArrayList<OnsiteCourse> searchOnsiteCourse(String column, String data){
        return ocDAL.searchOnsiteCourse(column, data);
    }
}
