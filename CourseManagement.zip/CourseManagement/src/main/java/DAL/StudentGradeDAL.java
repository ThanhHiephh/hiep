/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAL;
import Model.StudentGrade;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author HP ADMIN
 */
public class StudentGradeDAL extends SqlConnection{
    public ArrayList<StudentGrade> getAllStudentGrade(){
        ArrayList<StudentGrade> list = new ArrayList<>();
        if(openConnection()){
            try {
                String sql = "select *from StudentGrade";
                Statement stm = con.createStatement();
                ResultSet rs = stm.executeQuery(sql);
                while(rs.next()){
                    StudentGrade sg = new StudentGrade();
                    sg.setEnrollmentID(rs.getInt("EnrollmentID"));
                    sg.setCourseID(rs.getInt("CourseID"));
                    sg.setStudentID(rs.getInt("StudentID"));
                    sg.setGrade(rs.getDouble("Grade"));
                    list.add(sg);
                }
                
            } catch (SQLException ex) {
                Logger.getLogger(StudentGradeDAL.class.getName()).log(Level.SEVERE, null, ex);
            } finally{
                closeConnection();
            }
        }
        
        return list;
    }
    
    public boolean checkStudentGradeID(int enrollmentID){
        boolean check = false;
        if(openConnection()){
            try {
                String sql = "select * from StudentGrade where EnrollmentID = "+enrollmentID;
                Statement stm = con.createStatement();
                ResultSet rs = stm.executeQuery(sql);
                while(rs.next()){
                    check = true;
                }
            } catch (SQLException ex) {
                Logger.getLogger(StudentGradeDAL.class.getName()).log(Level.SEVERE, null, ex);
            } finally{
                closeConnection();
            }
            
        }
        
        return check;
    }
    
    public ArrayList<Integer> getAllStudentID(){
        ArrayList<Integer> list = new ArrayList<>();
        if(openConnection()){
            try {
                String sql = "select PersonID from Person where PersonID is not NULL";
                Statement stm = con.createStatement();
                ResultSet rs = stm.executeQuery(sql);
                while(rs.next()){
                    list.add(Integer.valueOf(rs.getInt("PersonID")));
                }
            } catch (SQLException ex) {
                Logger.getLogger(StudentGradeDAL.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                closeConnection();
            }
        }
        
        return list;
    }
    
    public ArrayList<Integer> getAllCourseID(){
        ArrayList<Integer> list = new ArrayList<>();
        if(openConnection()){
            try {
                String sql = "select CourseID from Course";
                Statement stm = con.createStatement();
                ResultSet rs = stm.executeQuery(sql);
                while(rs.next()){
                    list.add(Integer.valueOf(rs.getInt("CourseID")));
                }
            } catch (SQLException ex) {
                Logger.getLogger(StudentGradeDAL.class.getName()).log(Level.SEVERE, null, ex);
            } finally{
                closeConnection();
            }
        }
        return list;
    }
    
    public boolean addStudentGrade(StudentGrade sg){
        boolean check = false;
        if(openConnection()){
            try {
                String sql = "insert into StudentGrade values(?,?,?)";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setInt(1, sg.getCourseID());
                stm.setInt(2, sg.getStudentID());
                stm.setDouble(3, sg.getGrade());
                if(stm.executeUpdate()>=1){
                    check = true;
                }
            } catch (SQLException ex) {
                Logger.getLogger(StudentGradeDAL.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                closeConnection();
            }
            
        }
        return check;
    }
    
    public boolean deleteStudentGrade(int enrollmentID){
        boolean check = false;
        if(openConnection()){
            try {
                String sql = "delete from StudentGrade where EnrollmentID = ?";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setInt(1, enrollmentID);
                if(stm.executeUpdate()>=1){
                    check = true;
                }
            } catch (SQLException ex) {
                Logger.getLogger(StudentGradeDAL.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                closeConnection();
            }
            
        }
        
        return check;
    }
    
    public boolean updateStudentGrade(StudentGrade sg){
        boolean check = false;
        if(openConnection()){
            try {
                String sql = "update StudentGrade set CourseID = ?, PersonID = ?, Grade = ? where EnrollmentID = ?";
                PreparedStatement stm = con.prepareStatement(sql);
                stm.setInt(1, sg.getCourseID());
                stm.setInt(2, sg.getStudentID());
                stm.setDouble(3, sg.getGrade());
                stm.setInt(4, sg.getEnrollmentID());
                if(stm.executeUpdate()>=1){
                    check = true;
                }
            } catch (SQLException ex) {
                Logger.getLogger(StudentGradeDAL.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                closeConnection();
            }
        }
        
        return check;
    }
    
    public ArrayList<StudentGrade> searchStudentGrade(String column, String data){
        ArrayList<StudentGrade> list = new ArrayList<>();
        if(openConnection()){
            try {
                String sql = "select * from StudentGrade where "+column+" = "+data;
                Statement stm = con.createStatement();
                ResultSet rs = stm.executeQuery(sql);
                while(rs.next()){
                    StudentGrade sg = new StudentGrade();
                    sg.setEnrollmentID(rs.getInt("EnrollmentID"));
                    sg.setCourseID(rs.getInt("CourseID"));
                    sg.setStudentID(rs.getInt("StudentID"));
                    sg.setGrade(rs.getDouble("Grade"));
                    list.add(sg);
                }
            } catch (SQLException ex) {
                Logger.getLogger(StudentGradeDAL.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
                closeConnection();
            }
        }
        
        return list;
    }
}
